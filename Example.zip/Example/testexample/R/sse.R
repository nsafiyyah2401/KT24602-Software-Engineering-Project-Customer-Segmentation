# Function for data preprocessing
preprocess_data <- function(data) {
  # Perform data preprocessing steps
  preprocessed_data <- data * 2
  return(preprocessed_data)
}

# Function for modeling
train_model <- function(data) {
  # Train a simple model
  model <- lm(data ~ 1)
  return(model)
}
