# tests/testthat/test_my_functions.R

test_that("Test my functions", {
  expect_true(TRUE)
})
