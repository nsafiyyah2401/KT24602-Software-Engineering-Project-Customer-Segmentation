# R/data_analysis.R

# Function to calculate the mean
calculate_mean <- function(x) {
  mean(x)
}

# Function to calculate the median
calculate_median <- function(x) {
  median(x)
}

# Function to generate a scatter plot
generate_scatter_plot <- function(x, y, title = NULL, x_label = NULL, y_label = NULL) {
  plot(x, y, main = title, xlab = x_label, ylab = y_label)
}
